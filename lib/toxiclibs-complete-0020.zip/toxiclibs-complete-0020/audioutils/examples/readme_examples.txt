Due to the large(ish) file size of the demos, other examples for this
library are bundled separately and can be downloaded from the usual toxiclibs
download page:

http://code.google.com/p/toxiclibs/downloads/list

Have fun! :)